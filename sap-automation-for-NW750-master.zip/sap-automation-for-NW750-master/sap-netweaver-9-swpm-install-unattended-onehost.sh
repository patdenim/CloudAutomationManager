#!/usr/bin/env bash

# Script written by Sean Freeman, Shyamal Saha and Fabien Franchitto
# Designed for Development or Test usage only by IBMers.

###### NOTE ######

# If this script fails to execute with error \r command not found, use below to convert CRLF to LF
#sed -i "s/\r$//" filename


##################################################

# Step 7.3 - SWPM Unattended - Install One Host (DB Restore, MS, EN, GW, WP)

##################################################

echo "Apply execute permissions to SWPM and the params file"
#chmod -R 777 sapmnt
chmod -Rf 755 $SWPM_unattended_OneHost_parameters_file
#chmod -Rf 755 /software/SWPM10SP21

# Wait for processes to finish
sleep 15

echo "!!!!"
echo "WORKAROUND Copy files manually to directory, to resolve issue with SWPM when using edited control.xml"
echo "!!!!"

echo "**** WORKAROUND Attempt 2 - Stop SAP App Server services, run broken install to generate configuration files needed for PAS Installation... then install *****"

echo "Generate configuration files with SWPM command which cannot succeed (because params file is broken)"
# To resolve intermittent SWPM/SAPinst starts GUI during unattended and hangs, must use the pkill to stop any processes from previous SWPM/SAPinst run and use Java SDT GUI with client and server by using SAPINST_SLP_MODE=false
$SAP_SWPM_LOCATION/sapinst \
SAPINST_INPUT_PARAMETERS_URL=$PWD/IMAGINARY_FILE_TO_FAIL_SWPM_inifile.params \
SAPINST_EXECUTE_PRODUCT_ID=NW_ABAP_OneHost:NW750.HDB.ABAP \
SAPINST_SKIP_DIALOGS=true \
SAPINST_SLP_MODE=false \
SAPINST_MESSAGE_CONSOLE_THRESHOLD=warning \
SAPINST_MESSAGE_GUILOG_THRESHOLD=warning


echo ""
echo "Amend control.xml to skip unnecessary Create CDS DDL Views step during Installation"

# Remove Create CDS DDL Views step, remove STEP="RunRUTDDLSCREATE" entirely (by removing the line found + next 3 lines)
# N.B. Always remember that regex escape is \ for sed, and use lowercase n on first character in command to keep the pattern match line
#sed -i '/<step name="RunRUTDDLSCREATE">/{N;N;N;d}' control.xml

# The above sed command removes the following from control.xml in SP22
#<step name="RunRUTDDLSCREATE">
#  <display-name>Create DDL views (RUTDDLSCREATE). This might take a while.</display-name>
#  <script type="java"/>
#</step>

# Remove Create CDS DDL Views step, remove STEP="RunRUTDDLSCREATE" entirely by removing the line found until the next </step>. EG. This removes full XML Node.
# N.B. Always remember that regex escape is \ for sed, and use lowercase n on first character in command to keep the pattern match line
sed -i '/<step name="RunRUTDDLSCREATE">/,/<\/step>/d' control.xml

# In SP23 and above, this changed to....
#<step name="RunRUTDDLSCREATE">
#  <display-name>Create DDL views (RUTDDLSCREATE). This might take a while.</display-name>
#  <preprocess>
#    <script>
#      <![CDATA[
#      if (installer.onOS400()) {
#        OS4_Environment.setJavaStepEnv(context.get("Sid"));
#        OS4_Environment.setJavaStepUserEnv(context.get("Sid") + "ADM");
#      }
#      ]]>
#    </script>
#  </preprocess>
#  <script type="java"/>
#</step>


# If attempting to remove only the <script /> or <display></display> elements, the followiong SWPM error occurs:
# XML parsing error. DETAILS: XML parser reports an error, line X column Y during parsing file
# control.xml (content model of element 'step' not valid (content model: children) [vc: element
# valid]). SOLUTION: Contact SAP Support.

# When changing control.xml, this changes the file's SHA256 hash stored in signature.xml
# The signature.xml stores all SHA-256 has for all SWPM files, and then creates a hash signature at the end in format PKCS7-TSTAMP.
# This appears to refer to Secure Store and Forward Mechanism (SSF) format PKCS#7, and uses the Signature scheme with RSA key and SHA-256 hash algorithm (SAP Note 2004653 - CommonCryptoLib 8 cryptographic algorithms) and an embedded TimeStamp
# Which then uses thw Certificate Revocation List (CRL) to provide verification. This defaults to ~/.sapinst/crlbag.p7s and is amended with SAPinst property SAPINST_CRL_PATH
# Therefore, changing control.xml will cause immediate hang or exit after the SAPinst build information and sapparam are displayed.


# Fix SWPM 1.0 SP22 PL2 during execute step checkInstDirPermissions
# Error is "The read and execute bits for [user or group or others] are not set in directory /root SOLUTION: SAPinst will set the appropriate permission on the directory"
# First must create the sapinst user group and apply user root to the group, otherwise fix commands do not work
# However this hard writes GID as 1002, when this should be handled by SWPM during the first run. This is why SWPM Unattended Parameter `nwUsers.sapsysGID` is active but has no value

#groupadd --gid 1002 sapinst
#usermod --append --groups sapinst root

# Fix for SWPM 1.0 SP22 PL2 during execute step checkInstDirPermissions
# Error is "The read and execute bits for [user or group or others] are not set in directory /root SOLUTION: SAPinst will set the appropriate permission on the directory"
# Fix is to apply the executable bit (unfortunately it also requires read and write for some folders) to [user or group or others] for each folder in the directory patch

pathfix=$PWD
while [ "$pathfix" != "/" ]; do
  chmod ugo+rwx $pathfix
  pathfix=$(dirname $pathfix)
done

# Fix for SWPM 1.0 SP22 PL2 during execute step
# Error is
# Fix is to
chown -Rf root:sapinst $PWD


sleep 15
#pkill -USR1 sapinst

echo ""
echo "**** WORKAROUND Attempt 2 - END ****"
echo ""
echo ""
echo "Execute PAS installation with copied configuration files and amended control.xml"

# To resolve intermittent SWPM/SAPinst starts GUI during unattended and hangs, must use the pkill to stop any processes from previous SWPM/SAPinst run and use Java SDT GUI with client and server by using SAPINST_SLP_MODE=false

$SAP_SWPM_LOCATION/sapinst \
SAPINST_INPUT_PARAMETERS_URL=$PWD/$SWPM_unattended_OneHost_parameters_file \
SAPINST_CONTROL_URL=$PWD/control.xml \
SAPINST_EXECUTE_PRODUCT_ID=NW_ABAP_OneHost:NW750.HDB.ABAP \
SAPINST_SKIP_DIALOGS=true \
SAPINST_SLP_MODE=false \
SAPINST_MESSAGE_CONSOLE_THRESHOLD=warning \
SAPINST_MESSAGE_GUILOG_THRESHOLD=warning


function expose_function_as_parameter_on_script_exec() {

# This is only required if executing a script (eg. ./script.sh)
# and choosing the Bash Function inside the script to run using by passing a parameter (eg. ./script.sh function_to_run)

##################################################

# Expand arguements and call arguments verbatim "$@"
# https://stackoverflow.com/questions/8818119/how-can-i-run-a-function-from-a-script-in-command-line

##################################################

# Check if the function exists (bash specific)
#if declare -f "$1" > /dev/null

# Check if the function exists (bourne shell compliant)
tempvar1="$(type -t $1)"

if [ "$tempvar1" > /dev/null ]
  then
    # call arguments verbatim
    "$@"
  else
    # Show a helpful error
    echo "'$1' is not a known function name" >&2
    exit 1
  fi

}